<?php
echo "<h1> Payment failed";
?>
<a href="index.php"> <br>Back to Homepage</a>