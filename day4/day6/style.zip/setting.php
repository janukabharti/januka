<?php
$epay_url="https://rc-epay.esewa.com.np/api/epay/main/v2/form";
$pid="jerseystore1000009";
$failedurl="http://localhost/esewa_failed.php?q=fu";
$successurl="http://localhost/esewa_success.php?q=su";
$merchant_code="epay_payment";
$fraudcheck_url="https://uat.esewa.com.np/epay/transrec";
?>
